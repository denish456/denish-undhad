import cardimg_1 from "../../images/cardimgg1.png";
import cardimg_2 from "../../images/cardimgg2.png";
import cardimg_3 from "../../images/card_img_8.png";
import cardimg_4 from "../../images/cardimg4.png";
import cardimg_5 from "../../images/cardimg5.png";
import cardimg_6 from "../../images/cardimg6.png";
import cardimg_7 from "../../images/cardimg7.png";
import cardimg_8 from "../../images/cardimg8.png";
import cardimg_9 from "../../images/cardimg9.png";
import cardimg_10 from "../../images/card_img_10.png";
import cardimg_11 from "../../images/card_img_11.png";
import img2 from "../../images/Star.png";
import img1 from "../../images/img4.png";
import card2img1 from "../../images/card2img1.png";
import card2img2 from "../../images/card2img2.png";
import card2img3 from "../../images/card2img3.png";
import card2img4 from "../../images/card2img4.png";
export const card2 = [
  {
    Tages: "Vegetabel",
    Cardimg: img1,
    title: "Calabrese Broccoli",
    price: "20$",
    currentP: 13.00,
    Rating: img2,
  },
  {
    Tages: "Fresh",
    Cardimg: cardimg_1,
    title: "Fresh Banana Fruites",
    price: "20$",
    currentP: 14.00,
    Rating: img2,
  },
  {
    Tages: "Millets",
    Cardimg: cardimg_2,
    title: "White Nuts",
    price: "20$",
    currentP: 15.00,
    Rating: img2,
  },
  {
    Tages: "Vegetabel",
    Cardimg: cardimg_5,
    title: "Vegan Red Tomato",
    price: "20$",
    currentP: 17.00,
    Rating: img2,
  },
  {
    Tages: "Health",
    Cardimg: cardimg_6,
    title: "Mung Bean",
    price: "20$",
    currentP: 11.00,
    Rating: img2,
  },
  {
    Tages: "Nuts",
    Cardimg: cardimg_7,
    title: "Brown Hazelnut",
    price: "20$",
    currentP: 12.00,
    Rating: img2,
  },
  {
    Tages: "Fresh",
    Cardimg: cardimg_8,
    title: "Eggs",
    price: "20$",
    currentP: 17.00,
    Rating: img2,
  },
  {
    Tages: "Fresh",
    Cardimg: cardimg_9,
    title: "Zelco Suji Elaichi Rusk",
    price: "20$",
    currentP: 15.00,
    Rating: img2,
  },
  {
    Tages: "Health",
    Cardimg: cardimg_3,
    title: "Mung Bean",
    price: "20$",
    currentP: 11.00,
    Rating: img2,
  },
  {
    Tages: "Nuts",
    Cardimg: cardimg_4,
    title: "White Hazelnut",
    price: "20$",
    currentP: 12.00,
    Rating: img2,
  },
  {
    Tages: "Fresh",
    Cardimg: cardimg_10,
    title: "Fresh Corn",
    price: "20$",
    currentP: 17.00,
    Rating: img2,
  },
  {
    Tages: "Fresh",
    Cardimg: cardimg_11,
    title: "Organic Almonds",
    price: "20$",
    currentP: 15.00,
    Rating: img2,
  },

  {
    Tages: "Vegetabel",
    Cardimg: card2img4,
    title: "Mung Bean",
    price: "20$",
    currentP: 11.00,
    Rating: img2,
  },
  {
    Tages: "Vegetabel",
    Cardimg: card2img3,
    title: "Brown Hazelnut",
    price: "20$",
    currentP: 12.00,
    Rating: img2,
  },
  {
    Tages: "Vegetabel",
    Cardimg: card2img2,
    title: "Onion",
    price: "20$",
    currentP: 17.00,
    Rating: img2,
  },
  {
    Tages: "Vegetabel",
    Cardimg: card2img1,
    title: "Cabbage",
    price: "20$",
    currentP: 17.00,
    Rating: img2,
  },
];
